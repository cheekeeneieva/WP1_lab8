
document.addEventListener("DOMContentLoaded", () => {
//1
    function createEmptyArray(length: number): number [] {
        let n: number[] = [];
        for (let i = 0; i < length; i++) {
            n.push(0);
        }
        return n;
    }

    let f: number = 5;
    console.log("üäälength of an array: ", f)
    console.log("length of array is: ", f, " and array looks like this: ", createEmptyArray(f));

//2
    function createR(min: number, max: number): number {
        let z: number = Math.floor((Math.random() * max) + min);
        return z;
    }

    let min: number = 0;
    let max: number = 100;
    console.log("creating of one random number as a test: ", createR(min, max));

//3
//Die Funktion soll jedes Element des angegebenen Arrays mit einer zufäligen Ganzzahl zwischen
// min und max uberschreiben. Nutzen Sie dafür die Funktion createRandomInteger.
    function fillWithRandomNumbers(inputArray: number [], min: number, max: number): number [] {
        for (let i = 0; i < inputArray.length; i++) {
            inputArray[i] = createR(min, max);
        }
        return inputArray;
    }

    let len: number = Math.floor(Math.random() * 100);

    console.log("length of a random array: ", len, " and the array itself: ");

    console.log(fillWithRandomNumbers(createEmptyArray(len), min, max));

    let anArrayFilledWithRandomNumbers: number[] = fillWithRandomNumbers(createEmptyArray(len), min, max);

    console.log("anArrayFilledWithRandomNumbers: ", anArrayFilledWithRandomNumbers);

    let length_of_array: number = anArrayFilledWithRandomNumbers.length
//4
//Die Funktion soll das Element am Index indexA mit dem Element an Index indexB tauschen.
// Tipp: Speichern Sie sich eines der beiden Elemente zun¨achst als Hilfsvariable ab. Nun k¨onnen
// Sie die Werte jeweils neu zuweisen.

    function swap(toSwapeArray: number [], indexA: number, indexB: number): number [] {

        let toSwapeArray_fake: number[] = toSwapeArray;


        let temp: number = toSwapeArray_fake[indexA];
        toSwapeArray_fake[indexA] = toSwapeArray[indexB];
        toSwapeArray_fake[indexB] = temp;


        return toSwapeArray_fake;
    }

//AAAAAAAAAAAAAAAAAAAAAAAAA (Tutoren fragen!!!!)
//(die Frage: why is it undefined, when value random is?)
//Antwort: length_of_array (not a 100)

   // let n: number = Math.floor(Math.random() * length_of_array);
    //let m: number = Math.floor(Math.random() * length_of_array);
    let indexA: number = 1;
    let indexB: number = 3;

    console.log("a first random index of an array to change: ", indexA);
    console.log("a second random index of an array to change: ", indexB);
    console.log("and now swapped an indexA : ", indexA, " with an indexB : ", indexB);
    console.log("swaped 2 elements: ", swap(anArrayFilledWithRandomNumbers, indexA, indexB));

    let ANewArray: number[] = swap(anArrayFilledWithRandomNumbers, indexA, indexB);
//console.log(ANewArray);
//5 Die Funktion wendet den Bubble Sort auf das eingegebene Array an. Bubble Sort ist ein einfacher, aber ineffizienter Sortieralgorithmus. Er vergleicht wiederholt benachbarte Paare von
// Elementen im Array und vertauscht diese, falls sie in der falschen Reihenfolge sind. Sie finden
// auf Wikipedia2 den Pseudocode des Algorithmus, welcher nach TypeScript ubersetzt werden ¨
// kann. Außerdem k¨onnen Sie weitere Quellen3
// zur Funktionsweise des Algorithmus zu Rate ziehen. Nutzen Sie Ihre Funktion swap fur den Tausch der Elemente.

    function bubbleSort(array: number []): number [] {
        let len: number = array.length;
        for (let i = 0; i < len; i++) {
            for (let j = 0; j < len; j++) {

                if (array[j] > array[j + 1]) {
                    swap(array, j , j+1);
                    //  let x: number = array[j];
                    //  array[j]=array[j+1];
                    // array[j+1]=x;

                }
            }
        }

        return array;
    }

    let bubbleSorted_array: number[] = bubbleSort(ANewArray);
    console.log("a bubblesorted array: ", bubbleSorted_array);

//6 Die Funktion soll alle Elemente des Arrays auf der Seite ausgeben, indem das <body>-Element
// selektiert wird und fur jedes Array-Element ein ¨ <p>-Element erzeugt wird. Diese sollen den
// Wert des Array-Elements als Text-Content enthalten.

// printArray
    function printArray(array: number []): void {

        for (let i = 0; i < array.length; i++) {
            Number_in_Array.textContent = ` ${array[i].toString()}`;
            Elemente_des_Arrays.appendChild(Number_in_Array);


        }
    }
    const Elemente_des_Arrays = document.getElementById("table");
    const Number_in_Array = document.createElement("p");
    printArray(bubbleSorted_array);


//(g) Testen Sie Ihre Implementierungen, indem Sie den folgenden Code laufen lassen. Erkl¨aren Sie
// den Spruch ”
// Teile und herrsche“ im Kontext des gesamten Programms.



});
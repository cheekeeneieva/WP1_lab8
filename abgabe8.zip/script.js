document.addEventListener("DOMContentLoaded", function () {
    //1
    function createEmptyArray(length) {
        var n = [];
        for (var i = 0; i < length; i++) {
            n.push(0);
        }
        return n;
    }
    var f = 5;
    console.log("üäälength of an array: ", f);
    console.log("length of array is: ", f, " and array looks like this: ", createEmptyArray(f));
    //2
    function createR(min, max) {
        var z = Math.floor((Math.random() * max) + min);
        return z;
    }
    var min = 0;
    var max = 100;
    console.log("creating of one random number as a test: ", createR(min, max));
    //3
    //Die Funktion soll jedes Element des angegebenen Arrays mit einer zufäligen Ganzzahl zwischen
    // min und max uberschreiben. Nutzen Sie dafür die Funktion createRandomInteger.
    function fillWithRandomNumbers(inputArray, min, max) {
        for (var i = 0; i < inputArray.length; i++) {
            inputArray[i] = createR(min, max);
        }
        return inputArray;
    }
    var len = Math.floor(Math.random() * 100);
    console.log("length of a random array: ", len, " and the array itself: ");
    console.log(fillWithRandomNumbers(createEmptyArray(len), min, max));
    var anArrayFilledWithRandomNumbers = fillWithRandomNumbers(createEmptyArray(len), min, max);
    console.log("anArrayFilledWithRandomNumbers: ", anArrayFilledWithRandomNumbers);
    var length_of_array = anArrayFilledWithRandomNumbers.length;
    //4
    //Die Funktion soll das Element am Index indexA mit dem Element an Index indexB tauschen.
    // Tipp: Speichern Sie sich eines der beiden Elemente zun¨achst als Hilfsvariable ab. Nun k¨onnen
    // Sie die Werte jeweils neu zuweisen.
    function swap(toSwapeArray, indexA, indexB) {
        var toSwapeArray_fake = toSwapeArray;
        var temp = toSwapeArray_fake[indexA];
        toSwapeArray_fake[indexA] = toSwapeArray[indexB];
        toSwapeArray_fake[indexB] = temp;
        return toSwapeArray_fake;
    }
    //AAAAAAAAAAAAAAAAAAAAAAAAA (Tutoren fragen!!!!)
    //(die Frage: why is it undefined, when value random is?)
    //Antwort: length_of_array (not a 100)
    // let n: number = Math.floor(Math.random() * length_of_array);
    //let m: number = Math.floor(Math.random() * length_of_array);
    var indexA = 1;
    var indexB = 3;
    console.log("a first random index of an array to change: ", indexA);
    console.log("a second random index of an array to change: ", indexB);
    console.log("and now swapped an indexA : ", indexA, " with an indexB : ", indexB);
    console.log("swaped 2 elements: ", swap(anArrayFilledWithRandomNumbers, indexA, indexB));
    var ANewArray = swap(anArrayFilledWithRandomNumbers, indexA, indexB);
    //console.log(ANewArray);
    //5 Die Funktion wendet den Bubble Sort auf das eingegebene Array an. Bubble Sort ist ein einfacher, aber ineffizienter Sortieralgorithmus. Er vergleicht wiederholt benachbarte Paare von
    // Elementen im Array und vertauscht diese, falls sie in der falschen Reihenfolge sind. Sie finden
    // auf Wikipedia2 den Pseudocode des Algorithmus, welcher nach TypeScript ubersetzt werden ¨
    // kann. Außerdem k¨onnen Sie weitere Quellen3
    // zur Funktionsweise des Algorithmus zu Rate ziehen. Nutzen Sie Ihre Funktion swap fur den Tausch der Elemente.
    function bubbleSort(array) {
        var len = array.length;
        for (var i = 0; i < len; i++) {
            for (var j = 0; j < len; j++) {
                if (array[j] > array[j + 1]) {
                    swap(array, j, j + 1);
                    //  let x: number = array[j];
                    //  array[j]=array[j+1];
                    // array[j+1]=x;
                }
            }
        }
        return array;
    }
    var bubbleSorted_array = bubbleSort(ANewArray);
    console.log("a bubblesorted array: ", bubbleSorted_array);
    //6 Die Funktion soll alle Elemente des Arrays auf der Seite ausgeben, indem das <body>-Element
    // selektiert wird und fur jedes Array-Element ein ¨ <p>-Element erzeugt wird. Diese sollen den
    // Wert des Array-Elements als Text-Content enthalten.
    // printArray
    function printArray(array) {
        for (var i = 0; i < array.length; i++) {
            Number_in_Array.textContent = " ".concat(array[i].toString());
            Elemente_des_Arrays.appendChild(Number_in_Array);
        }
    }
    var Elemente_des_Arrays = document.getElementById("table");
    var Number_in_Array = document.createElement("p");
    printArray(bubbleSorted_array);
    //(g) Testen Sie Ihre Implementierungen, indem Sie den folgenden Code laufen lassen. Erkl¨aren Sie
    // den Spruch ”
    // Teile und herrsche“ im Kontext des gesamten Programms.
});
